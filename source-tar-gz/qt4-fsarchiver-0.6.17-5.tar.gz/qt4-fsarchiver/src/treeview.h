/*
 * qt4-fsarchiver: Filesystem Archiver
 * 
* Copyright (C) 2008-2014 Dieter Baum.  All rights reserved.
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public
 * License v2 as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License for more details.
 *
 */

#ifndef TREEVIEW_H
#define TREEVIEW_H
#include <QtGui>
#include <QDialog>
#include "ui_treeview.h"

using namespace std;

class TreeviewRead : public QDialog, private Ui::treeview_dialog
{
	Q_OBJECT

public:
	TreeviewRead(QWidget *parent = 0);
        QString folder_treeview_holen();

private:
	QDirModel *dirModel;
    	QItemSelectionModel *selModel;       
	
private slots:	
        void folder_einlesen();
        void folder_einlesen_beenden();
};

#endif




